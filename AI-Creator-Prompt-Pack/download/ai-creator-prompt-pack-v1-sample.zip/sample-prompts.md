# Free Sample Prompts

## 1. Creator Action Figure

Create an action-figure style package for [creator persona]. Include safe abstract accessories related to [niche], such as [accessories]. Preserve identity and outfit cues. Use premium toy packaging and realistic product lighting. Keep all branding marks abstract and unreadable.

## 2. App Hero Mockup

Create a clean hero image for [app name], an app that helps [target user] do [benefit]. Show a phone with an abstract app interface, realistic hand placement, and a lifestyle context. Leave space for headline copy. Avoid readable fake UI text.

## 3. Korean Launch Visual

[app name] 출시 홍보용 정사각형 이미지를 만들어줘. 앱이 주는 핵심 이점인 [benefit]이 한눈에 보이게 하고, 나중에 문구를 얹을 수 있도록 여백을 남겨줘. 이미지 안에는 읽을 수 있는 글자를 넣지 마.

## 4. Clean Profile Headshot

Create a clean professional profile headshot of [subject]. Preserve identity, age, hairstyle, and natural expression. Use a neutral studio background, soft even lighting, realistic skin texture, sharp eyes, and confident chest-up framing. Avoid logos, text, heavy beauty filters, extra people, and changing identity.

## 5. Productized Service Visual

Create a premium service-package visual for [service offer]. Use a polished desk scene, deliverable cards, abstract charts, and a confident consulting-product mood. The image should feel practical and credible. Do not include readable text or logos.
