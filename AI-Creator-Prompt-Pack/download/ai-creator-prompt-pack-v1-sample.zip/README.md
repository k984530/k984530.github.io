# AI Creator Prompt Pack v1 - Free Sample

This free sample previews the full AI Creator Prompt Pack.

The full paid pack includes:

- 60 AI creator prompts
- 7 repeatable workflows
- 90 Korean and English caption starters
- Personal and commercial-use terms

Price target: 29,000 KRW

Full product page:

https://won-space.com/AI-Creator-Prompt-Pack/

## How To Use This Sample

1. Pick one prompt.
2. Replace bracketed fields like `[subject]` or `[app name]`.
3. Generate 4 variations.
4. Keep the strongest result.
5. Pair it with one caption starter.

The sample is intentionally small. The full pack is built for repeatable weekly content production.
