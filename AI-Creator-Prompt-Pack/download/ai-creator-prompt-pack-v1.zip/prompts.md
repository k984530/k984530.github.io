# AI Creator Prompt Pack v1 - Prompts

Use these as starting points. Replace bracketed text with the creator, brand, app, or style details.

## Profile And Headshot Prompts

1. Clean creator headshot: `Create a clean professional profile headshot of [subject]. Preserve identity, age, hairstyle, and natural expression. Use a neutral studio background, soft even lighting, realistic skin texture, sharp eyes, and confident chest-up framing. Avoid logos, text, heavy beauty filters, extra people, and changing identity.`
2. Warm founder portrait: `Create a warm founder portrait of [subject] for a personal brand page. Preserve identity and outfit cues. Use natural window light, soft shadows, approachable posture, and a subtle workspace background. The mood should feel trustworthy, practical, and human.`
3. Minimal social avatar: `Turn [subject] into a minimal high-contrast social avatar. Preserve face identity and hairstyle. Use a clean single-color background, soft rim light, and crisp crop that works at small sizes. Avoid readable text or brand logos.`
4. Editorial creator bio: `Create an editorial creator bio photo of [subject]. Keep the face recognizable. Use magazine-style lighting, simple background depth, refined color grading, and a composed pose suitable for a creator media kit.`
5. LinkedIn refresh: `Create a realistic LinkedIn-ready headshot from [photo]. Preserve identity and natural expression. Use business-casual styling, neutral background, soft professional lighting, and polished but not over-retouched skin.`
6. Studio profile set: `Create a studio profile portrait of [subject] with a calm expression, realistic camera lens perspective, clean shadow falloff, and balanced skin tones. The result should feel suitable for portfolio, resume, and team pages.`
7. Dark-mode avatar: `Create a profile portrait of [subject] designed for a dark app interface. Preserve identity. Use a charcoal background, subtle color accent, clear facial lighting, and strong small-avatar readability.`
8. Creator verification photo: `Create a polished account verification-style portrait of [subject]. Preserve identity, pose, and expression. Use simple lighting, centered framing, plain background, and no added text or logos.`

## AI Figurine And Toy-Box Prompts

9. Collectible figurine: `Turn [subject] into a collectible 3D figurine in a clear retail blister pack on a store shelf. Preserve recognizable face, hairstyle, outfit colors, and pose. Use realistic plastic material, studio product lighting, and abstract unreadable package graphics.`
10. Desk toy figure: `Create a desk toy figurine version of [subject]. Preserve key identity cues. Use rounded vinyl-toy proportions, matte plastic, a small display base, soft studio lighting, and a clean product photography background.`
11. Fashion doll box: `Turn [subject] into a fashionable doll inside luxury retail packaging with a polished plastic window and harmless accessory slots. Keep branding abstract and unreadable. Avoid detached body parts, horror props, and unsettling replacement parts.`
12. Creator action figure: `Create an action-figure style package for [creator persona]. Include safe abstract accessories related to [niche], such as [accessories]. Preserve identity and outfit cues. Use premium toy packaging and realistic product lighting.`
13. Mini shelf scene: `Create a miniature shelf display scene featuring a toy version of [subject]. Add soft retail lights, a clean shelf, product-photo depth of field, and a playful collectible mood.`
14. Blind-box character: `Turn [subject] into a blind-box collectible character. Preserve face and hair cues while simplifying proportions into a cute premium toy. Use a compact box beside the character, abstract marks only, no readable text.`
15. Premium statue: `Create a premium display statue of [subject] on a simple pedestal. Preserve identity cues and outfit impression. Use realistic resin material, sculpted details, controlled studio lighting, and a collector-product feel.`
16. Toy ad creative: `Create a square social ad-style image for a collectible toy version of [subject]. Show the figure, package, and clean background. Leave empty space for later copy, but do not add readable text.`

## Lifestyle Creator Prompts

17. Coffee shop post: `Create a natural lifestyle photo of [subject] at a quiet coffee shop. Preserve identity, outfit feel, and realistic proportions. Use soft daylight, candid posture, and a calm creator-diary mood.`
18. Gym mirror routine: `Create a tasteful gym lifestyle photo of [subject] after a workout. Keep it natural and non-sexual. Use clean mirror framing, athletic outfit, realistic lighting, and a disciplined routine mood.`
19. City walk reel cover: `Create a city-walk image of [subject] for a short-form video cover. Use golden-hour street light, motion-friendly composition, and a confident casual outfit. Leave clean space for later title overlay without adding text.`
20. Desk setup creator: `Create a creator desk setup portrait of [subject]. Include laptop, notebook, phone, and tidy practical workspace details. Keep the person recognizable and the scene realistic.`
21. Rainy window mood: `Create a cinematic rainy-window portrait of [subject]. Use soft reflections, moody natural light, and a quiet inner-life feeling. Preserve face identity and avoid dramatic fantasy changes.`
22. Weekend outfit: `Create a polished weekend outfit photo of [subject]. Use natural outdoor lighting, clean background, realistic fabric detail, and a social-feed ready crop.`
23. Night street style: `Create a night street-style portrait of [subject]. Use neon accents, wet pavement reflection, realistic skin texture, and confident editorial framing.`
24. Travel diary: `Create a travel diary image of [subject] in [location type]. Preserve identity. Use natural tourist-photo realism, warm color grading, and a candid sense of movement.`

## App And Product Promo Prompts

25. App hero mockup: `Create a clean hero image for [app name], an app that helps [target user] do [benefit]. Show a phone with an abstract app interface, realistic hand placement, and a lifestyle context. Avoid readable fake UI text.`
26. Before-after product story: `Create a before-and-after style promotional visual for [app/product]. Show the input situation on the left and improved result on the right. Keep composition clear, modern, and ad-ready. Do not add readable text.`
27. Store screenshot background: `Create a bright app-store screenshot background for [app category]. Use clean visual metaphors, soft depth, and space for UI screenshots. Avoid text, logos, and clutter.`
28. Social launch tile: `Create a square social launch tile for [app/product]. Show the product benefit visually, leave room for headline overlay, use high contrast, and keep the image instantly understandable.`
29. Feature explainer image: `Create a visual explainer for [feature]. Show the user action, the app response, and the final benefit in one clean composition. No readable text, no fake brand logos.`
30. Productized service visual: `Create a premium service-package visual for [service offer]. Use a polished desk scene, deliverable cards, abstract charts, and a confident consulting-product mood.`
31. Testimonial backdrop: `Create a social proof backdrop for [product]. Use subtle profile silhouettes, rating-card shapes, and calm trust-building colors. Do not include readable names, quotes, or logos.`
32. Pricing page hero: `Create a pricing page hero image for [product]. Use clean product objects, credit/token visual metaphor, and organized composition that feels simple rather than pushy.`

## Short-Form Video And Reels Prompts

33. Hook cover: `Create a vertical short-form video cover image for the hook: [hook]. Show [subject/product] in a clear visual situation that communicates the premise instantly. Leave empty top space for text overlay.`
34. Transformation reel: `Create a vertical image showing the first frame of a transformation reel from [before state] to [after state]. Make the before state visually obvious and leave room for overlay text.`
35. Day-in-life opener: `Create a natural day-in-life opener image for [creator persona]. Show the first moment of the day, practical details, and a human routine mood.`
36. Myth-busting cover: `Create a bold vertical cover image for a myth-busting post about [topic]. Use expressive body language, clear visual contrast, and space for later text.`
37. Tutorial thumbnail: `Create a vertical tutorial thumbnail for [how-to topic]. Show the tool, the result, and a clean visual arrow-like flow without adding actual arrows or text.`
38. Behind-the-scenes: `Create a behind-the-scenes image of [creator/product workflow]. Use realistic messy-but-tidy details, warm lighting, and a practical creator mood.`
39. Results reveal: `Create a dramatic but realistic reveal image for [result]. Use anticipation, clean framing, and a final-output focus. Keep it believable and not overproduced.`
40. Comparison carousel cover: `Create a carousel cover image comparing [option A] and [option B]. Make the contrast visible through composition and color, but do not add readable text.`

## Korean Market Prompts

41. Korean profile photo: `한국 사용자를 위한 깔끔한 프로필 사진을 만들어줘. [subject]의 얼굴, 헤어스타일, 나이감, 자연스러운 표정을 유지하고, 부드러운 조명과 단정한 배경을 사용해. 과한 보정, 로고, 글자, 다른 사람 추가는 피해야 해.`
42. Korean creator daily look: `[subject]의 자연스러운 일상 피드 사진을 만들어줘. 카페나 거리에서 찍은 듯한 현실적인 분위기, 단정한 스타일, 부드러운 색감, 과하지 않은 포즈를 사용해.`
43. Korean app launch visual: `[app name] 출시 홍보용 정사각형 이미지를 만들어줘. 앱이 주는 핵심 이점인 [benefit]이 한눈에 보이게 하고, 나중에 문구를 얹을 수 있도록 여백을 남겨줘. 이미지 안에는 읽을 수 있는 글자를 넣지 마.`
44. Korean AI figurine: `[subject]를 수집용 피규어 패키지 스타일로 바꿔줘. 실제 얼굴과 스타일은 유지하고, 투명 플라스틱 박스, 매장 진열 느낌, 제품 사진 조명, 귀여운 액세서리 슬롯을 넣어줘. 읽을 수 있는 브랜드명은 넣지 마.`
45. Korean short reel cover: `[topic]에 대한 숏폼 커버 이미지를 만들어줘. 세로형 화면, 강한 첫인상, 상단 문구 영역, 자연스러운 인물 표정, 명확한 상황 연출을 사용해.`
46. Korean soft influencer: `AI 인플루언서 [persona]의 부드러운 라이프스타일 사진을 만들어줘. 자연광, 일상적인 장소, 과하지 않은 패션, 친근한 표정, 현실적인 피부 질감을 유지해.`
47. Korean productized service: `[service] 상품을 소개하는 프리미엄 이미지가 필요해. 노트북, 체크리스트, 결과물 카드, 정돈된 책상, 신뢰감 있는 색감을 사용하고, 텍스트는 넣지 마.`
48. Korean before-after: `[before]에서 [after]로 바뀌는 전후 비교 이미지를 만들어줘. 좌우 차이가 한눈에 보이되, 과장 광고처럼 보이지 않게 현실적인 결과 중심으로 구성해.`

## Advanced Prompt Formulas

49. Identity-preserving formula: `Transform [subject] into [style] while preserving face identity, hairstyle, age, expression, outfit color cues, and main pose. Use [lighting], [background], and [camera feel]. Avoid [forbidden elements].`
50. Product ad formula: `Create a promotional image for [product] showing [target user] achieving [benefit]. Use [visual metaphor], [setting], and [mood]. Leave room for copy overlay. Do not add readable text or logos.`
51. Creator niche formula: `Create a creator image for [niche] that feels [emotion]. Show [subject] doing [action] in [setting]. Use realistic details connected to [niche props]. Preserve identity and avoid exaggerated stereotypes.`
52. Carousel formula: `Create image [number] of a carousel about [topic]. This slide should visually communicate [point]. Use [composition], [color mood], and clear empty space for later copy. No readable text.`
53. Brand consistency formula: `Create a [format] image for [brand/persona] using consistent traits: [colors], [clothing], [setting], [mood], [camera style]. The result should match previous posts while still feeling new.`
54. App screenshot formula: `Create a background scene for an app screenshot about [feature]. Use [visual symbols] and [target user context]. Keep the center area clean for a phone UI mockup. No readable text.`
55. Launch sequence formula: `Create launch image [1/3/5] for [product]. The message is [message]. Make the visual feel [emotion], show [object/person/result], and leave room for headline overlay.`
56. Seasonal campaign formula: `Create a seasonal campaign visual for [product/persona] around [season/event]. Use [setting], [props], and [color mood]. Keep it culturally appropriate and avoid readable text.`
57. Trust builder formula: `Create a trust-building visual for [service/app]. Show [proof metaphor], [calm setting], and [organized deliverables]. Make it practical and credible, not flashy.`
58. Conversion CTA formula: `Create a conversion-focused image for [offer]. Show the final desirable outcome, a clean path to get there, and a confident visual mood. Leave empty space for call-to-action copy.`
59. Community post formula: `Create a community-style image for [audience] around [shared feeling]. Make it relatable, warm, and easy to comment on. Use simple composition and realistic details.`
60. Weekly batch formula: `Generate a set of 5 image concepts for [persona/product] this week: one profile asset, one lifestyle post, one educational post, one product promo, and one behind-the-scenes image. Keep style consistent: [style rules].`
