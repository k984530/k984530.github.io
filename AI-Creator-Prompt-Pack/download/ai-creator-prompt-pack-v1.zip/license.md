# AI Creator Prompt Pack v1 - License

## Personal And Commercial Use

You may use the prompts, workflows, and caption starters to create images, posts, landing assets, app launch concepts, and client deliverables for yourself or your business.

## Client Work

You may use the pack while producing work for clients, including custom prompt systems, image concepts, content calendars, and marketing drafts.

## What You May Not Do

- Resell this pack as-is.
- Repackage the files into another prompt pack or course without substantial original work.
- Upload the full files to public repositories, marketplaces, or prompt databases.
- Claim the original pack text as your exclusive authorship.

## Responsibility

Generated outputs depend on the AI tool, source images, model settings, and local rules. Review every output before publishing. Do not use generated images in ways that misrepresent real people, violate platform policies, or imply endorsement without permission.

## Version

AI Creator Prompt Pack v1
Created: 2026-05-22
