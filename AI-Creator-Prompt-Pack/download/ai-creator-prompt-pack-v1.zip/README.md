# AI Creator Prompt Pack v1

Price target: 29,000 KRW

This pack is built for solo creators, AI influencers, small app teams, and social media operators who need repeatable image and short-form content ideas without starting from a blank prompt.

## What Is Inside

- `prompts.md`: 60 ready-to-use prompts across profile photos, figurines, lifestyle shots, product promos, Reels hooks, and app launch posts.
- `workflows.md`: 7 practical workflows for turning prompts into posts, profile assets, app-store style creatives, and weekly content batches.
- `caption-bank.md`: 90 caption starters in Korean and English.
- `license.md`: clear personal and commercial usage terms.

## Best For

- AI influencer accounts that need daily visual concepts
- App makers creating organic launch posts
- Small teams refreshing profile, product, or landing visuals
- Creators who want repeatable prompt formulas instead of one-off prompt guessing

## Quick Start

1. Pick one workflow from `workflows.md`.
2. Choose 3 prompts from the matching section in `prompts.md`.
3. Generate 4 variations per prompt.
4. Keep the strongest 3 images.
5. Pair each image with a caption starter from `caption-bank.md`.

## Suggested Upsell

Offer a custom prompt bundle as a separate service:

- 10 custom prompts: 59,000 KRW
- 30 custom prompts: 149,000 KRW
- Full brand prompt system: 390,000 KRW+
