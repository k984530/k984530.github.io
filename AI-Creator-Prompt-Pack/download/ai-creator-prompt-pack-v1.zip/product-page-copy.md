# AI Creator Prompt Pack v1 - Product Page Copy

## Headline

AI Creator Prompt Pack

## Subheadline

60 prompts, 7 workflows, and 90 caption starters for AI influencers, app launch posts, profile refreshes, and product visuals.

## Price

29,000 KRW

## Short Description

Stop starting every AI image from a blank prompt. This pack gives you repeatable prompt formulas for creator profiles, AI figurines, lifestyle posts, app launch visuals, Reels covers, and productized service offers.

## What You Get

- 60 ready-to-use prompts
- 7 practical content workflows
- 90 Korean and English caption starters
- Personal and commercial-use terms
- Markdown files delivered in a ZIP

## Who It Helps

- AI influencer operators
- Solo app makers
- Social media managers
- Small studios
- Founders refreshing their profile and launch visuals

## CTA

Email `alyduho984530@gmail.com` with the subject `AI Creator Prompt Pack` to buy the 29,000 KRW pack.
