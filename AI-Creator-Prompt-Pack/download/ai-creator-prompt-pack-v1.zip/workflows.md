# AI Creator Prompt Pack v1 - Workflows

## Workflow 1: One-Hour AI Influencer Batch

Goal: prepare one week of visual post concepts without publishing anything yet.

1. Choose one persona and write 3 style rules: outfit, setting, color mood.
2. Use prompts 17, 19, 21, 23, and 46.
3. Generate 4 variations for each prompt.
4. Keep 7 images: 5 feed candidates and 2 story candidates.
5. Pair each with a caption starter from `caption-bank.md`.
6. Save filenames as `YYYY-MM-DD-persona-post-01`.

## Workflow 2: App Launch Social Kit

Goal: create organic launch assets for a mobile app.

1. Define the app benefit in one sentence.
2. Use prompts 25, 26, 28, 29, and 32.
3. Keep the visuals text-free so final copy can be localized.
4. Create 3 launch captions:
   - what it does
   - who it helps
   - what to try first
5. Publish only after final account/post confirmation.

## Workflow 3: Profile Refresh Pack

Goal: generate profile images for a creator, founder, or app persona.

1. Use prompts 1, 2, 4, 5, and 7.
2. Keep one polished headshot and one warmer lifestyle portrait.
3. Use the same image across profile, landing page, and press kit only if identity consistency matters.
4. Avoid changing facial structure when the image represents a real person.

## Workflow 4: AI Figurine Viral Test

Goal: create a shareable toy-style post series.

1. Use prompts 9, 10, 11, 12, and 14.
2. Generate both square feed versions and vertical story versions.
3. Pair the post with a caption that asks a simple preference question.
4. Track saves, comments, and profile visits before making more.

## Workflow 5: Productized Service Offer

Goal: package prompt work as a service.

1. Pick a niche: app launch, influencer profile, founder headshot, or local business social kit.
2. Use prompts 30, 47, 57, and 58 to create service visuals.
3. Offer a fixed deliverable:
   - 10 prompts
   - 20 generated image directions
   - 5 caption starters
4. Quote a fixed price and delivery time.

## Workflow 6: Store Screenshot Ideation

Goal: create direction boards for App Store or Google Play screenshot refreshes.

1. Use prompts 25, 27, 29, 32, and 54.
2. Generate backgrounds only, without fake UI text.
3. Place actual app screenshots on top in the design tool.
4. Keep screenshot copy short and benefit-led.

## Workflow 7: Weekly Learning Loop

Goal: turn content into repeatable revenue learning.

1. Each week pick one offer and one audience.
2. Create 5 post concepts using prompt 60.
3. Publish only after confirmation.
4. Track clicks, saves, replies, profile visits, and purchases.
5. Keep the top-performing prompt formula and replace the weakest one.
