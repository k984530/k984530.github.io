# AI Creator Prompt Pack v1 - Caption Bank

## Korean Caption Starters

1. 오늘은 한 장의 사진으로 어디까지 바뀔 수 있는지 테스트했다.
2. 이 스타일은 프로필 사진보다 조금 더 기억에 남는다.
3. AI 이미지가 좋아지는 순간은 프롬프트가 짧아지는 순간이다.
4. 결과물보다 중요한 건 반복 가능한 공식이다.
5. 저장해두면 다음 콘텐츠 만들 때 바로 쓸 수 있다.
6. 같은 사진도 방향을 바꾸면 완전히 다른 브랜드가 된다.
7. 첫인상은 생각보다 작은 디테일에서 갈린다.
8. 오늘의 실험: [style] 스타일.
9. 이 버전이 더 자연스러운지, 더 강한지 고민 중.
10. 콘텐츠는 감이 아니라 시스템으로 굴러가야 오래 간다.
11. 프로필 사진 하나만 바꿔도 계정 분위기가 달라진다.
12. 브랜드가 아직 작을수록 시각적 일관성이 더 중요하다.
13. 한 번에 완벽하게 만들기보다, 4개 만들고 하나 고르는 쪽이 빠르다.
14. 이 프롬프트는 앱 홍보 이미지에도 바로 응용 가능하다.
15. 오늘 만든 것 중 가장 저장 가치가 높은 컷.
16. AI 크리에이터에게 필요한 건 더 긴 문장이 아니라 더 좋은 구조다.
17. 이건 피드용, 다음 버전은 스토리용으로 테스트.
18. 결과가 애매하면 배경, 조명, 포즈 중 하나만 바꿔본다.
19. 작은 계정일수록 한눈에 설명되는 이미지가 유리하다.
20. 이번 주 콘텐츠 방향은 더 깔끔하고 더 직접적으로.
21. 한 장의 이미지가 서비스 설명보다 빠를 때가 있다.
22. 피규어 스타일은 댓글을 부르기 좋다.
23. 프로필 헤드샷은 신뢰감을 먼저 만든다.
24. 제품 이미지는 예쁘기보다 이해가 빨라야 한다.
25. 이 조합은 랜딩 페이지 히어로에도 잘 맞는다.
26. AI로 만든 이미지는 마지막 편집에서 완성된다.
27. 문구를 넣기 전에 이미지 자체가 말이 되는지 먼저 본다.
28. 오늘의 기준: 작게 봐도 알아볼 수 있는가.
29. 프롬프트를 상품처럼 관리하면 콘텐츠 속도가 달라진다.
30. 다음 실험은 같은 콘셉트로 5장 배치 만들기.

## English Caption Starters

31. One photo, one clear style direction, four usable variations.
32. The best prompt is the one you can repeat next week.
33. This started as a simple profile refresh test.
34. The goal is not more content. The goal is repeatable content.
35. A clean visual system beats a random viral attempt.
36. This one feels ready for a launch post.
37. Same subject, different story.
38. Prompt structure matters more than prompt length.
39. I would use this as a profile image, not just a one-off edit.
40. The first three seconds of a visual decide whether people keep looking.
41. This is what I mean by a practical AI creator workflow.
42. Build the formula once, reuse it all month.
43. A good image should make the offer easier to understand.
44. This version is cleaner. The next test will be bolder.
45. Save this if you make creator assets with AI.
46. This is a visual direction, not just a generated image.
47. Small brands need fast clarity.
48. If the image needs a paragraph to explain it, regenerate.
49. AI content gets better when you edit the system, not just the prompt.
50. This would work as a carousel opener.
51. The strongest posts usually come from the clearest constraint.
52. I like this because it feels usable, not overproduced.
53. This prompt can become a profile photo, ad concept, or launch tile.
54. A prompt pack is useful only when it saves decisions.
55. The output should look like it belongs to the same account.
56. Repeatability is the real content advantage.
57. This is a good test for app launch visuals.
58. The toy-box style is built for comments.
59. The headshot style is built for trust.
60. The product visual is built for conversion.

## CTA Starters

61. Want the prompt formula? I packaged the workflow.
62. Comment `PROMPT` and I will send the structure.
63. I turned this into a reusable prompt pack.
64. The full pack includes prompts, workflows, and caption starters.
65. Use it for profile images, app launch posts, and AI influencer batches.
66. Built for creators who need repeatable visuals.
67. Built for app makers who need launch assets fast.
68. Built for small teams without a full design department.
69. DM for the prompt pack.
70. Available as a fixed-price digital pack.

## Soft-Sell Starters

71. This is the kind of prompt I wish I had saved earlier.
72. The result is nice, but the reusable structure is the real asset.
73. Most creators do not need more tools. They need fewer blank pages.
74. This is for people who want practical AI images, not prompt theater.
75. The pack is intentionally simple: prompts, workflows, captions.
76. No giant course, no complicated setup.
77. Use it, adapt it, save the strongest formulas.
78. Start with one workflow and publish only what fits your brand.
79. The best version is the one that ships.
80. Simple prompt systems compound.

## Product Page Bullets

81. 60 ready-to-use AI creator prompts
82. 7 workflows for weekly content batches
83. 90 Korean and English caption starters
84. Built for AI influencers, solo founders, and app launch posts
85. Includes profile, figurine, lifestyle, product, and Reels directions
86. Text-free visual prompts so you can localize final copy
87. Commercial-use friendly for your own content and client work
88. Delivered as a ZIP of Markdown files
89. Designed to save decisions, not teach theory
90. Price target: 29,000 KRW
